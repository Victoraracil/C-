using System; 

class Ejercicio1{ //(1.8.3) Intenta crear una nueva versión del programa que calcula el producto de los números 87 y 94, usando esta vez variables llamadas "numero 1" y "numero 2".
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int numero1 = 87, numero2 = 91;
		int x = numero1 * numero2;
		System.Console.WriteLine("87*94=" );
		System.Console.WriteLine(x);
	
	}
}
