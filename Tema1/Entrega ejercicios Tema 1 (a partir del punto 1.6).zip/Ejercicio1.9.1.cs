using System; 

class Ejercicio1{ //(1.9.1) Crea un programa que convierta una cantidad prefijada de metros (por ejemplo, 3000) a millas. La equivalencia es 1 milla = 1609 metros. Usa comentarios donde te parezca adecuado.
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int numero1 = 3000, numero2 = 1609; //Declaracion de las variables
		int x = numero1 * numero2; //declaracion de x para guardar el valir final
		System.Console.WriteLine("3000 metros son " + (x) + " millas"); //Texto final
	
	}
}
