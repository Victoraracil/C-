using System; 

class Ejercicio1{ //(1.6.2.2) Calcula el resultado de (20+5) % 6
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int x = 0;
		x = 20 + 5;
		System.Console.WriteLine("(20+5) % 6=");
		System.Console.WriteLine(x % 6);
	}
}
