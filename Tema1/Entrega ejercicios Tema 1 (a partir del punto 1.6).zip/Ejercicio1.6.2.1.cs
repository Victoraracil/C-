using System; 

class Ejercicio1{
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int x = 0;
		x = 3*5;
		System.Console.WriteLine("-2+3*5=");
		System.Console.WriteLine(x - 2);
		
	}	
}
