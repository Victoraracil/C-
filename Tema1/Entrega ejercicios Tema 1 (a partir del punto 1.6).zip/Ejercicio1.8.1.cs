using System; 

class Ejercicio1{ //(1.8.1) Crea un programa que calcule el producto de los números 87 y 94, usando variables llamadas "numero1" y "numero2"
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int numero1 = 87, numero2 = 91;
		int x = numero1 * numero2;
		System.Console.WriteLine("87*94=" );
		System.Console.WriteLine(x);
	
	}
}
