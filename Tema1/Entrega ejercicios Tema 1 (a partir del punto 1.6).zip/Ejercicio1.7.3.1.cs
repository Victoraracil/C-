using System; 

class Ejercicio1{ //(1.7.3.1) Crea un programa que calcule el producto de los números 121 y 132, usando variables.
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int n1 = 121, n2 = 132;		
		int x = n1 * n2;
		
		System.Console.WriteLine("121*132=");
		System.Console.WriteLine(x);
	
	}
}
