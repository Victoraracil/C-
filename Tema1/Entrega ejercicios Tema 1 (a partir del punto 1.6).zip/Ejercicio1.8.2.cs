using System; 

class Ejercicio1{ //(1.8.2) Intenta crear una nueva versión del programa que calcula el producto de los números 87 y 94, usando esta vez variables llamadas "1numero" y "2numero".
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int 1numero = 87, 2numero = 91;
		int x = 1numero * 2numero;
		System.Console.WriteLine("87*94=" );
		System.Console.WriteLine(x);
	
	}
}
