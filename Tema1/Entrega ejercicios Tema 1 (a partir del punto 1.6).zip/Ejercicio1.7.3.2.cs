using System; 

class Ejercicio1{ //(1.7.3.2) Crea un programa que calcule la suma de 285 y 1396, usando variables.
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int n1 = 285, n2 = 1396;		
		int x = n1 * n2;
		
		System.Console.WriteLine("285*1396=");
		System.Console.WriteLine(x);
	
	}
}
