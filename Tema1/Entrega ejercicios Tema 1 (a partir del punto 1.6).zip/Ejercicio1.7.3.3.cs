using System; 

class Ejercicio1{ //(1.7.3.3) Crea un programa que calcule el resto de dividir 3784 entre 16, usando variables.
	public static void Main(){
		
		System.Console.WriteLine("Ejemplo de precedencia de operadores");
		int n1 = 3784, n2 = 16;		
		float x = n1 % n2;
		
		System.Console.WriteLine("3784%16=");
		System.Console.WriteLine(x);
	
	}
}
