﻿using System;

/*Amplía el esqueleto del ConsoleInvaders (6.6.3): La clase Enemigo tendrá un
segundo constructor, sin parámetros, que prefijará su posición inicial a (100,80)
para estas primeras pruebas. La clase Nave tendrá un segundo constructor, con
parámetros X e Y, para poder colocar la nave en otra posición desde Main. Verás
que hay código repetitivo en esos dos contructores, pero más adelante lo
optimizaremos.*/
class Nave : Sprite
{
    public Nave()
    {
        x = 60; y = 22;
        imagen = "/!\\";
    }
    public Nave(int x, int y)
    {

    }
    public void MoverDerecha()
    {
        MoverA("derecha");
    }
    public void MoverIzquierda()
    {
        MoverA("izquierda");
    }

}