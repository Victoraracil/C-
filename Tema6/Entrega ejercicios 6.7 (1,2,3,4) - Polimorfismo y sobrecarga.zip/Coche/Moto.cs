﻿using System;
/*Crea dos nuevos métodos en la clase Vehiculo (ejercicio 6.6.4): uno llamado
Circular, que fijará su "velocidad" (un nuevo atributo) a 50, y otro Circular(v), que
fijará su velocidad al valor que se indique como parámetro.*/
class Moto : Vehiculo
{
    public Moto()
    {
        SetRuedas(2);
    }
}
