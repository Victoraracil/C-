﻿using System;

class IngenieroInformatico : Ingeniero
{
    public IngenieroInformatico()
    {
        Console.WriteLine("Soy ingeniero informatico");
    }
}