﻿using System;

class Analista : Trabajador
{
    public Analista()
    {
        Console.WriteLine("Soy analista");
    }
}

