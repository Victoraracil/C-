﻿using System;


class Ingeniero : Trabajador
{
    public Ingeniero()
    {
        Console.WriteLine("Soy ingeniero");
    }
}
