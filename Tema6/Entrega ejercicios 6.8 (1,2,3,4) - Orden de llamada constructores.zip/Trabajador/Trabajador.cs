﻿using System;

class Trabajador
{
    public Trabajador()
    {
        Console.WriteLine("Soy un trabajador");
    }
}
