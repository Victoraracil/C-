﻿using System;

class Programador : Trabajador
{
    public Programador()
    {
        Console.WriteLine("Soy programador");
    }
}

