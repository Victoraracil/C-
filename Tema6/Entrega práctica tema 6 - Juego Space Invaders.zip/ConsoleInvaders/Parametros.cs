﻿using System;

class Parametros
{
    public const int ANCHO = 120;
    public const int ALTO = 29;

    public static Random random = new Random();

    public const int ANCHO_TORRE = 6;

    public const int PAUSA_BUCLE = 70;

    public const int SEPARACION_ENEMIGOS = 5;

    public const int VIDAS_INICIALES = 3;
    public const int PUNTOS_ENEMIGO1 = 10;
    public const int PUNTOS_ENEMIGO2 = 20;
    public const int PUNTOS_ENEMIGO3 = 30;
    public const int PUNTOS_OVNI = 100;
}