﻿using System;

class ConsoleInvaders
{

    public static void Main()
    {
        //Console.BackgroundColor = ConsoleColor.White;
        Juego j = new Juego();
        j.Lanzar();
    }
}