﻿using System;
    /*Amplía el esqueleto del ConsoleInvaders (ejercicio 6.3.6): Crea una clase
    "Sprite", de la que heredarán "Nave" y "Enemigo". La nueva clase contendrá todos
    los atributos y métodos que son comunes a las antiguas (todos los existentes, por
    ahora). A cambio, verás que tanto la nave como el enemigo tendrán la misma
    “imagen”, pero eso lo solucionaremos pronto.*/

class Sprite
{
    int x = 40;
    int y = 22;
    string imagen = "/\\";

    public void MoverA()
    {
        //x++; y --;   
    }
    public void Dibujar()
    {
        Console.SetCursorPosition(this.x, this.y);
        Console.WriteLine(imagen);


    }
}

