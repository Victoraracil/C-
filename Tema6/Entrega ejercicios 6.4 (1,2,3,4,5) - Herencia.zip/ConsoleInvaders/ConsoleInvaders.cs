﻿using System;

class ConsoleInvaders
{
    public static void Main()
    {
        Juego j = new Juego();
        j.Lanzar();
    }
}