﻿using System;
/*Amplía el proyecto de la clase Coche (ejercicio 6.3.7): Crea una clase
"Vehiculo", de la que heredarán "Coche" y una nueva clase "Moto". La clase
Vehiculo contendrá todos los atributos y métodos que antes estaban en Coche, y
tanto Coche como Moto heredarán de ella.*/

class Coche : Vehiculo
{
    
}
