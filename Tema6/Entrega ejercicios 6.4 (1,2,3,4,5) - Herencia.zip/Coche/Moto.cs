﻿using System;
class Moto : Vehiculo
{

}
