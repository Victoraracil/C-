﻿using System;

class Hardware
{
    public void BorrarPantalla()
    {
        for (byte i = 0; i < 25; i++)
            Console.WriteLine();
    }
}
