﻿using System;
class PruebaDeLibro
{
    public static void Main()
    {
        ListaDeDocumentos lista = new ListaDeDocumentos();
        lista.MostrarMenu();
    }
}
