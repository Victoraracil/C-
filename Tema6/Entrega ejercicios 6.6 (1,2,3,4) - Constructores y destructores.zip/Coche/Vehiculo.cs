﻿using System;
/*Mejora el proyecto de la clase Coche (ejercicio 6.5.5): añade un atributo
"cantidadDeRuedas" a la clase Vehiculo, junto con sus Get y Set. El constructor de
la clase Coche le dará el valor 4 y el constructor de la clase Moto le dará el valor 2.*/
class Vehiculo
{
    protected string marca;
    protected string modelo;
    protected int cilindrada;
    protected float potencia;
    protected int ruedas;
    public void SetMarca()
    {
        marca = Console.ReadLine();
    }
    public void SetModelo()
    {
        modelo = Console.ReadLine();
    }
    public void SetCilindrada()
    {
        cilindrada = Convert.ToInt32(Console.ReadLine());
    }
    public void SetPotencia()
    {
        potencia = Convert.ToInt32(Console.ReadLine());
    }
    public void SetRuedas(int ruedas)
    {
        this.ruedas = ruedas;
    }
    public void GetMarca()
    {
        this.marca = marca;
        return;
    }
    public void GetModelo()
    {
        this.modelo = modelo;
        return;
    }
    public void GetCilindrada()
    {
        this.cilindrada = cilindrada;
        return;
    }
    public void GetPotencia()
    {
        this.potencia = potencia; 
        return;
    }
    public void GetRuedas()
    {
        this.ruedas = ruedas;
        return;
    }
    public void MostrarDatos()
    {
        GetMarca();
        GetModelo();
        GetCilindrada();
        GetPotencia();
        GetRuedas();
        Console.WriteLine("Marca: " + marca);
        Console.WriteLine("Modelo: " + modelo);
        Console.WriteLine("Cilindrada: " + cilindrada);
        Console.WriteLine("Potencia: " + potencia);
        Console.WriteLine("Ruedas: " + ruedas);

    }
}
