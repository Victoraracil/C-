﻿using System;
/*Mejora el proyecto de la clase Coche (ejercicio 6.5.5): añade un atributo
"cantidadDeRuedas" a la clase Vehiculo, junto con sus Get y Set. El constructor de
la clase Coche le dará el valor 4 y el constructor de la clase Moto le dará el valor 2.*/

class Coche : Vehiculo
{
    public Coche()
    {
        SetRuedas(4);
    }
}
