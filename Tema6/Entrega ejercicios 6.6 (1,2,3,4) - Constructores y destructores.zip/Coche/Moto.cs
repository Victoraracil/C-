﻿using System;
class Moto : Vehiculo
{
    public Moto()
    {
        SetRuedas(2);
    }
}
