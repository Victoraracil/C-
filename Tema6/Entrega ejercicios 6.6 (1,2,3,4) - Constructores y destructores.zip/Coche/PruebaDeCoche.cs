﻿using System;

/*Mejora el proyecto de la clase Coche (ejercicio 6.5.5): añade un atributo
"cantidadDeRuedas" a la clase Vehiculo, junto con sus Get y Set. El constructor de
la clase Coche le dará el valor 4 y el constructor de la clase Moto le dará el valor 2.*/

class PruebaDeCoche
{
    public static void Main()
    {
        Coche c = new Coche();
        Console.WriteLine("Introduce la marca del choche:");
        c.SetMarca();
        Console.WriteLine("Introduce el modelo del choche:");
        c.SetModelo();
        Console.WriteLine("Introduce la cilindrada del choche:");
        c.SetCilindrada();
        Console.WriteLine("Introduce la potencia del choche:");
        c.SetPotencia();
        Console.WriteLine();
        c.MostrarDatos();
    }
}
