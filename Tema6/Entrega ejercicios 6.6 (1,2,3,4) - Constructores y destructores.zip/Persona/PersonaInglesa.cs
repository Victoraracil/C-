﻿using System;
/*Amplia las clases del ejercicio 6.5.2, para que todas ellas contengan
constructores. Los constructores de casi todas las clases estarán vacíos, excepto
del de PersonaInglesa, que prefijará su nombre a "John". Crea también un
constructor alternativo para esta clase que permita escoger cualquier otro
nombre.*/

class PersonaInglesa : Persona
{
    public PersonaInglesa()
    {
        this.nombre = "John";
    }
    public PersonaInglesa(string nombre)
    {
        this.nombre = nombre;
    }
    public void TomarTe()
    {
        Console.WriteLine("Estoy tomando té");
    }

    public void SaludoIngles(string nombre)
    {
        this.nombre = nombre;
        Console.WriteLine("Hi, I am " + nombre);
    }
}