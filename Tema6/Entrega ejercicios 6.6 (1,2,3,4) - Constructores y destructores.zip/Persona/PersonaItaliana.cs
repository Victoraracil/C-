﻿using System;
/*Amplia las clases del ejercicio 6.5.2, para que todas ellas contengan
constructores. Los constructores de casi todas las clases estarán vacíos, excepto
del de PersonaInglesa, que prefijará su nombre a "John". Crea también un
constructor alternativo para esta clase que permita escoger cualquier otro
nombre.*/
class PersonaItaliana : Persona
{
    protected string nombre;
    public PersonaItaliana()
    {

    }    
    public void SaludoItaliano(string nombre)
    {
        this.nombre = nombre;
        Console.WriteLine("Ciao " + nombre);
    }

}
