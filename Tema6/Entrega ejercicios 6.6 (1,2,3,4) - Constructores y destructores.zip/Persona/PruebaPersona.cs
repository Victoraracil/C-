﻿using System;
/*Amplia las clases del ejercicio 6.5.2, para que todas ellas contengan
constructores. Los constructores de casi todas las clases estarán vacíos, excepto
del de PersonaInglesa, que prefijará su nombre a "John". Crea también un
constructor alternativo para esta clase que permita escoger cualquier otro
nombre.*/
class PruebaPersona
{
    static void Main()
    {
        Persona p = new Persona();
        PersonaItaliana p2 = new PersonaItaliana();
        PersonaInglesa p3 = new PersonaInglesa();
        Console.WriteLine("Escibe el nombre de la persona inglesa:");
        string nombre = Console.ReadLine();
        PersonaInglesa p4 = new PersonaInglesa(nombre);
        
        
        p.SetNombre("Pepe");
        p.Saludar();
      
        Console.WriteLine();

        p2.SetNombre("Musolini");
        p2.SaludoItaliano("Musolini");

        Console.WriteLine();

        p3.SetNombre("John");
        p3.SaludoIngles("John");
        p3.TomarTe();

        Console.WriteLine();

        p4.SetNombre(nombre);
        p4.SaludoIngles(nombre);
        p4.TomarTe();
    }
}
