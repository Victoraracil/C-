﻿using System;
/*Retoca el proyecto del ejercicio 6.4.3 (Libro): los atributos de la clase
Documento y de la clase Libro serán "protegidos".*/
class Documento
{
    protected string autor;
    protected string titulo;
    protected string ubicacion;
    public void GetTitulo()
    {
        this.titulo = titulo;
        return;
    }
    public void GetAutor()
    {
        this.autor = autor;
        return;
    }
    public void GetUbicacion()
    {
        this.ubicacion = ubicacion;
        return;
    }
    public void SetTitulo()
    {
         titulo = "Los Juegos del Hambre";
        return;
    }
    public void SetAutor()
    {
         autor = "Suzanne Collins";
        return;
    }
    public void SetUbicacion()
    {
         ubicacion = "EEUU";
        return;
    }
    public void MostrarDocumento()
    {
        GetTitulo();
        GetAutor();
        GetUbicacion();
        Console.WriteLine("Titulo: " + titulo);
        Console.WriteLine("Autor: " + autor); 
        Console.WriteLine("Ubicacion: " + ubicacion);
    }
}

