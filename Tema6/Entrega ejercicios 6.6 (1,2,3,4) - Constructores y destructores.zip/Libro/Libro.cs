﻿using System;
/*Amplía el proyecto del ejercicio 6.5.3 (Libro): la clase Libro tendrá un
constructor que permita dar valores al autor, el título y la ubicación.*/

class Libro : Documento
{
    protected int paginas;

    public Libro(string titulo, string autor, string ubicacion)
    {
        this.titulo = titulo;
        this.autor = autor;
        this.ubicacion = ubicacion;
    }
    public void SetPaginas()
    {
        this.paginas = 200;
        return;
    }
    public void GetPaginas()
    {
        this.paginas = paginas;
    }
    public void MostrarPaginas()
    {
        GetPaginas();
        Console.WriteLine("Paginas: " + paginas);
    }
}

