﻿using System;
/*Retoca el proyecto del ejercicio 6.4.3 (Libro): los atributos de la clase
Documento y de la clase Libro serán "protegidos".*/
class PruebaDeLibro
{
    
    public static void Main()
    {
        string titulo;
        string autor;
        string ubicacion;
        Documento d = new Documento();
        d.SetTitulo();
        d.SetAutor();
        d.SetUbicacion();
        d.MostrarDocumento();
        Console.WriteLine();
        Console.WriteLine("Introduce el titulo de tu libro:");
        titulo = Console.ReadLine();
        Console.WriteLine("Introduce el autor de tu libro:");
        autor = Console.ReadLine();
        Console.WriteLine("Introduce la ubicacion de tu libro:");
        ubicacion = Console.ReadLine();
        Libro l = new Libro(titulo, autor, ubicacion);
        l.GetTitulo();
        l.GetAutor();
        l.GetUbicacion();
        l.SetPaginas();
        l.MostrarPaginas();
    }
}
