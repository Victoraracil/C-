﻿using System;
/*Mejora el proyecto de la clase Coche (ejercicio 6.4.5): todos los atributos
serán "protegidos" y los métodos serán "públicos".*/

class Coche : Vehiculo
{
    
}
