﻿using System;

/*Mejora el proyecto de la clase Coche (ejercicio 6.4.5): todos los atributos
serán "protegidos" y los métodos serán "públicos".*/

class PruebaDeCoche
{
    public static void Main()
    {
        Coche c = new Coche();
        Console.WriteLine("Introduce la marca del choche:");
        c.SetMarca();
        Console.WriteLine("Introduce el modelo del choche:");
        c.SetModelo();
        Console.WriteLine("Introduce la cilindrada del choche:");
        c.SetCilindrada();
        Console.WriteLine("Introduce la potencia del choche:");
        c.SetPotencia();
        Console.WriteLine();
        c.MostrarDatos();
    }
}
