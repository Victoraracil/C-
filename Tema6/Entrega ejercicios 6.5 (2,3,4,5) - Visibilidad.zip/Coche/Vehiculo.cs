﻿using System;
/*Mejora el proyecto de la clase Coche (ejercicio 6.4.5): todos los atributos
serán "protegidos" y los métodos serán "públicos".*/
class Vehiculo
{
    protected string marca;
    protected string modelo;
    protected int cilindrada;
    protected float potencia;
    public void SetMarca()
    {
        marca = Console.ReadLine();
    }
    public void SetModelo()
    {
        modelo = Console.ReadLine();
    }
    public void SetCilindrada()
    {
        cilindrada = Convert.ToInt32(Console.ReadLine());
    }
    public void SetPotencia()
    {
        potencia = Convert.ToInt32(Console.ReadLine());
    }
    public void GetMarca()
    {
        this.marca = marca;
        return;
    }
    public void GetModelo()
    {
        this.modelo = modelo;
        return;
    }
    public void GetCilindrada()
    {
        this.cilindrada = cilindrada;
        return;
    }
    public void GetPotencia()
    {
        this.potencia = potencia; 
        return;
    }
    public void MostrarDatos()
    {
        GetMarca();
        GetModelo();
        GetCilindrada();
        GetPotencia();
        Console.WriteLine("Marca: " + marca);
        Console.WriteLine("Modelo: " + modelo);
        Console.WriteLine("Cilindrada: " + cilindrada);
        Console.WriteLine("Potencia: " + potencia);

    }
}
