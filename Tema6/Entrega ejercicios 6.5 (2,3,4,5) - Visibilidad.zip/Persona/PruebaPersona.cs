﻿using System;
/*Amplía las clases del ejercicio 6.4.2, creando un nuevo proyecto con las
siguientes características: La clase Persona no cambia; la clase PersonaInglesa se
modificará para que redefina el método "Saludar", para que escriba en pantalla
"Hi, I am " seguido de su nombre; se creará una nueva clase PersonaItaliana, en el
fichero "personaItaliana.cs", que deberá heredar las características de la clase
"Persona", pero redefinir el método "Saludar", para que escriba en pantalla "Ciao";
crea también una clase llamada PruebaPersona3, en el fichero
"pruebaPersona3.cs", que deberá contener sólo la función Main y creará un objeto
de tipo Persona, uno de tipo PersonaInglesa, uno de tipo PersonaItaliana, les
asignará un nombre, les pedirá que saluden y pedirá a la persona inglesa que
tome té.*/
class PruebaPersona
{
    static void Main()
    {
        Persona p = new Persona();
        PersonaItaliana p2 = new PersonaItaliana();
        PersonaInglesa p3 = new PersonaInglesa();
        
        p.SetNombre("Pepe");
        p.Saludar();
      
        Console.WriteLine();

        p2.SetNombre("Musolini");
        p2.SaludoItaliano("Musolini");

        Console.WriteLine();

        p3.SetNombre("John");
        p3.SaludoIngles("John");
        p3.TomarTe();
    }
}
