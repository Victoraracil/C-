﻿using System;
/*Retoca el proyecto del ejercicio 6.4.3 (Libro): los atributos de la clase
Documento y de la clase Libro serán "protegidos"..*/

class Libro : Documento
{
    protected int paginas;

    public void SetPaginas()
    {
        this.paginas = 200;
        return;
    }
    public void GetPaginas()
    {
        this.paginas = paginas;
    }
    public void MostrarPaginas()
    {
        GetPaginas();
        Console.WriteLine("Paginas: " + paginas);
    }
}

