﻿using System;
/*Retoca el proyecto del ejercicio 6.4.3 (Libro): los atributos de la clase
Documento y de la clase Libro serán "protegidos".*/
class PruebaDeLibro
{
    public static void Main()
    {
        Documento d = new Documento();
        d.SetTitulo();
        d.SetAutor();
        d.SetUbicacion();
        d.MostrarDocumento();
        Console.WriteLine();
        Libro l = new Libro();
        l.SetPaginas();
        l.MostrarPaginas();
    }
}
