﻿namespace Academia._01view
{
    partial class FrmCursos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnFind = new Button();
            btnRemo = new Button();
            btnEdit = new Button();
            btnDR = new Button();
            btnR = new Button();
            btnL = new Button();
            btnDL = new Button();
            dataGridView1 = new DataGridView();
            lblPrecio = new Label();
            textBox5 = new TextBox();
            lblNoPlaza = new Label();
            textBox4 = new TextBox();
            lblLugar = new Label();
            textBox3 = new TextBox();
            lblTit = new Label();
            textBox2 = new TextBox();
            lblCod = new Label();
            textBox1 = new TextBox();
            btnClear = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnFind
            // 
            btnFind.Location = new Point(525, 324);
            btnFind.Name = "btnFind";
            btnFind.Size = new Size(63, 23);
            btnFind.TabIndex = 38;
            btnFind.Text = "Find";
            btnFind.UseVisualStyleBackColor = true;
            // 
            // btnRemo
            // 
            btnRemo.Location = new Point(456, 324);
            btnRemo.Name = "btnRemo";
            btnRemo.Size = new Size(63, 23);
            btnRemo.TabIndex = 37;
            btnRemo.Text = "Remove";
            btnRemo.UseVisualStyleBackColor = true;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(387, 324);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(63, 23);
            btnEdit.TabIndex = 35;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnDR
            // 
            btnDR.Location = new Point(318, 324);
            btnDR.Name = "btnDR";
            btnDR.Size = new Size(63, 23);
            btnDR.TabIndex = 34;
            btnDR.Text = ">>";
            btnDR.UseVisualStyleBackColor = true;
            // 
            // btnR
            // 
            btnR.Location = new Point(249, 324);
            btnR.Name = "btnR";
            btnR.Size = new Size(63, 23);
            btnR.TabIndex = 33;
            btnR.Text = ">";
            btnR.UseVisualStyleBackColor = true;
            // 
            // btnL
            // 
            btnL.Location = new Point(180, 324);
            btnL.Name = "btnL";
            btnL.Size = new Size(63, 23);
            btnL.TabIndex = 32;
            btnL.Text = "<";
            btnL.UseVisualStyleBackColor = true;
            // 
            // btnDL
            // 
            btnDL.AutoSize = true;
            btnDL.Location = new Point(111, 324);
            btnDL.Name = "btnDL";
            btnDL.Size = new Size(63, 25);
            btnDL.TabIndex = 31;
            btnDL.Text = "<<";
            btnDL.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(303, 61);
            dataGridView1.Margin = new Padding(3, 2, 3, 2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(379, 187);
            dataGridView1.TabIndex = 30;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(101, 233);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(43, 15);
            lblPrecio.TabIndex = 29;
            lblPrecio.Text = "Precio:";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(150, 228);
            textBox5.Margin = new Padding(3, 2, 3, 2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(110, 23);
            textBox5.TabIndex = 28;
            // 
            // lblNoPlaza
            // 
            lblNoPlaza.AutoSize = true;
            lblNoPlaza.Location = new Point(39, 188);
            lblNoPlaza.Name = "lblNoPlaza";
            lblNoPlaza.Size = new Size(105, 15);
            lblNoPlaza.TabIndex = 27;
            lblNoPlaza.Text = "Numero de plazas:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(150, 185);
            textBox4.Margin = new Padding(3, 2, 3, 2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(110, 23);
            textBox4.TabIndex = 26;
            // 
            // lblLugar
            // 
            lblLugar.AutoSize = true;
            lblLugar.Location = new Point(29, 145);
            lblLugar.Name = "lblLugar";
            lblLugar.Size = new Size(115, 15);
            lblLugar.TabIndex = 25;
            lblLugar.Text = "Lugar de realizacion:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(150, 142);
            textBox3.Margin = new Padding(3, 2, 3, 2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(110, 23);
            textBox3.TabIndex = 24;
            // 
            // lblTit
            // 
            lblTit.AutoSize = true;
            lblTit.Location = new Point(103, 105);
            lblTit.Name = "lblTit";
            lblTit.Size = new Size(41, 15);
            lblTit.TabIndex = 23;
            lblTit.Text = "Titulo:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(150, 97);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(110, 23);
            textBox2.TabIndex = 22;
            // 
            // lblCod
            // 
            lblCod.AutoSize = true;
            lblCod.Location = new Point(95, 64);
            lblCod.Name = "lblCod";
            lblCod.Size = new Size(49, 15);
            lblCod.TabIndex = 21;
            lblCod.Text = "Codigo:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(150, 61);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(110, 23);
            textBox1.TabIndex = 20;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(594, 324);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(63, 23);
            btnClear.TabIndex = 48;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // FrmCursos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(738, 411);
            Controls.Add(btnClear);
            Controls.Add(btnFind);
            Controls.Add(btnRemo);
            Controls.Add(btnEdit);
            Controls.Add(btnDR);
            Controls.Add(btnR);
            Controls.Add(btnL);
            Controls.Add(btnDL);
            Controls.Add(dataGridView1);
            Controls.Add(lblPrecio);
            Controls.Add(textBox5);
            Controls.Add(lblNoPlaza);
            Controls.Add(textBox4);
            Controls.Add(lblLugar);
            Controls.Add(textBox3);
            Controls.Add(lblTit);
            Controls.Add(textBox2);
            Controls.Add(lblCod);
            Controls.Add(textBox1);
            Name = "FrmCursos";
            Text = "FrmCursos";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnFind;
        private Button btnRemo;
        private Button btnEdit;
        private Button btnDR;
        private Button btnR;
        private Button btnL;
        private Button btnDL;
        private DataGridView dataGridView1;
        private Label lblPrecio;
        private TextBox textBox5;
        private Label lblNoPlaza;
        private TextBox textBox4;
        private Label lblLugar;
        private TextBox textBox3;
        private Label lblTit;
        private TextBox textBox2;
        private Label lblCod;
        private TextBox textBox1;
        private Button btnClear;
    }
}