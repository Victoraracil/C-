﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using academia_03data;
using Mysqlx.Datatypes;
using Org.BouncyCastle.Math;

class GestionAlumnos
{
    public Alumno Alumno { set; get; } //El alumno con el que trabajaremos
    public GestionAlumnos()
    {
        Alumno = new Alumno();
    }
    public string Error()
    {
        return BaseDatos.Error;
    }
    public Alumno Primero()
    {
        DataTable dt = BaseDatos.Consulta("select * from alumnos order by dni");
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (Alumno);
        }
        return (null);

    }
    public Alumno Ultimo()
    {
        DataTable dt = BaseDatos.Consulta("select * from alumnos order by dni desc");
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (Alumno);
        }
        return (null);

    }
    public Alumno Siguiente()
    {
        DataTable dt = BaseDatos.Consulta("select * from alumnos where dni > '" + this.Alumno.Dni +
            "' order by dni");
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (Alumno);
        }
        return (null);

    }
    public Alumno Anterior()
    {
        DataTable dt = BaseDatos.Consulta("select * from alumnos where dni < '" + this.Alumno.Dni +
            "' order by dni desc");
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (Alumno);
        }
        return (null);

    }
    public int Edit()
        {
            string sql = "select * from alumnos where dni = '" + this.Alumno.Dni + "'";
            if (BaseDatos.Consulta(sql).Rows.Count > 0)
            {
                sql = "update alumnos set nombre = '" + this.Alumno.Nombre + "', apellidos = '"
                + this.Alumno.Apellidos + "', telefono = '" + this.Alumno.Telefono +
                "', poblacion = '" + this.Alumno.Poblacion + "' where dni = '" + this.Alumno.Dni +
                "'";
                return (BaseDatos.Modificacion(sql));
            }
            return -1;
        }
    public int Insert()
    {
        string sql = "select * from alumnos where dni = '" + this.Alumno.Dni + "'";
        if (BaseDatos.Consulta(sql).Rows.Count == 0)
        {
            sql = "insert into alumnos values ('" + this.Alumno.Dni + "', '" +
            this.Alumno.Nombre + "', '" + this.Alumno.Apellidos + "', '" +
            this.Alumno.Telefono + "', '" + this.Alumno.Poblacion + "')";
            return (BaseDatos.Modificacion(sql));
        }
        return -1;

    }
    public int Remove()
    {
        string sql = "select * from alumnos where dni = '" + this.Alumno.Dni + "'";
        if (BaseDatos.Consulta(sql).Rows.Count > 0)
        {
            sql = "delete from alumnos where dni = '" + this.Alumno.Dni + "'";
            return (BaseDatos.Modificacion(sql));
        }
        return -1;

    }
    public Alumno GetById(string dni)
    {
        DataTable dt = BaseDatos.Consulta("select * from alumnos where dni = '" + dni + "'");
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno a = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (a);
        }
        return (null);
    }
    public List<Alumno> GetAll()
    {
        List<Alumno> alumnos = new List<Alumno>();
        DataTable dt = BaseDatos.Consulta("select * from alumnos order by dni");
        for (int i = 0; dt != null && i < dt.Rows.Count; i++)
        {
            alumnos.Add(new Alumno(dt.Rows[i]["dni"].ToString(), dt.Rows[i]["nombre"].ToString(),
            dt.Rows[i]["apellidos"].ToString(), dt.Rows[i]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString()));
        }
        return (alumnos);
    }
    public Alumno GetOneBySql(string sql)
    {
        DataTable dt = BaseDatos.Consulta(sql);
        if (dt != null && dt.Rows.Count > 0)
        {
            Alumno a = new Alumno(dt.Rows[0]["dni"].ToString(), dt.Rows[0]["nombre"].ToString(),
            dt.Rows[0]["apellidos"].ToString(), dt.Rows[0]["telefono"].ToString(), dt.Rows[0]
            ["poblacion"].ToString());
            return (a);
        }
        return (null);
    }
    public DataTable GetAllBySql(string sql)
    {
        return BaseDatos.Consulta(sql);
    }
}